
package sword.princess;

/**
 *This abstract class contains the monster which will appear and attack the princess
 * @author Patricia Virgen and  Hitarth Asrani   
 */
public abstract class Monsters 
{
    //instance variables 
    
    public String monsterName; 
    public int monsterHeight;
    public int monsterSpeed;
    
    
    
    //constructors 
    
    public Monsters()
    {
        this.monsterName = "Monster!" ; // out three possible name one will be generated in the subclass 
        this.monsterHeight = 0;
        this.monsterSpeed = 0;
        
    }

    //methods
    
    public abstract String Name();
    
    public abstract int Speed();

    public abstract int Height();
    
    
}
