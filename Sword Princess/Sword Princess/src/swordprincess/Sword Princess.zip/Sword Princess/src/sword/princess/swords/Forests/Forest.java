/***

This class Forest has a similar structure for all of them with a slightly change in the looks and the level of difficulty depending on the map 
/**
 *
 * @author Patricia
 */
package sword.princess.swords.Forests;

public class Forest
{
    
}
