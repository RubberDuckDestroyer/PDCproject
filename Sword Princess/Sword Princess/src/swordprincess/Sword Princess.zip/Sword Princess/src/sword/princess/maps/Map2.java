/*
 This map is the one that looks the prettiest, but there are rocks that she needs to jump over to collect the large number of available flowers. Lots of zombies appear from behind the trees s
 */
package sword.princess.maps;

/**
 *
 * @author Patricia Virgen and Hitarth Asrani   
 */
public class Map2 
{
    
}
