/***
 This class: helps defeating dragon but makes other fights tough
 *
 * @author Patricia Virgen  and  Hitarth Asrani   
 ***/
package sword.princess.swords;


public class DualSword {
    
}
