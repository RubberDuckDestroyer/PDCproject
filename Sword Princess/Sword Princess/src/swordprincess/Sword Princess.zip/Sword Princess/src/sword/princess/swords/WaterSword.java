/***
*This class gives more flowers on killing.
* 
* * @author Patricia Virgen  and  Hitarth Asrani   
 ***/
package sword.princess.swords;


public class WaterSword 
{
    
}
