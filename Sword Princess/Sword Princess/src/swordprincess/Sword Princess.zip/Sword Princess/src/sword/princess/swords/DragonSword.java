/***
 This class: Deals more damage to zombies but weak against dragon. 
 *
 * @author Patricia Virgen  and  Hitarth Asrani   
 ***/
package sword.princess.swords;


public class DragonSword {
    
}
