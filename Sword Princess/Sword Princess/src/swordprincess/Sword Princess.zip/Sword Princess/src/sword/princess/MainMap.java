
package sword.princess;

/**
 * This is our main map which provides the methods and attributes that its subclasses: Map1, Map2, and Map3 will need to override to suit the their own specifications 
 *  since they will have different rooms 
 *
 * @author Patricia Virgen and Hitarth Asrani  
 ***/
public abstract class MainMap 
{
    //instance variables that all maps will have 
    public SwordPrincess princes;
    public int numOfMons;
    public int numOfRooms;
   
    
    
}