/***
 * This class: kills easier but lesser flowers dropped.
 * 
 * 
 * @author Patricia Virgen  and  Hitarth Asrani   
 ***/
package sword.princess.swords;


public class FireSword {
    
}
