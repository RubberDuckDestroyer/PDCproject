/*
 * This clas represents the flowers which the princess will collect in orther to gain more points or survive accoding to her situation 
 */
package sword.princess;

/**
 *
 * @author Patricia Virgen and Hitarth Asrani   
 */
public class Flowers 
{
    //instance variables 
    
    private int numOfFlowers;   
   
    // constructor
   public Flowers()
    {
        
    }
    
   //methods
    public int getNumOfFlowers()
    {
        return numOfFlowers;
    }

    public void setNumOfFlowers(int numOfFlowers)
    {
        this.numOfFlowers = numOfFlowers;
    }
    
 
    
}
