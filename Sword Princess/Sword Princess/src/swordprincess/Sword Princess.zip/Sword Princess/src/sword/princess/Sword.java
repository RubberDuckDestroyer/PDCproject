package sword.princess;

/***
This class contains the essential methods and attributes that all swords will have 



 *
 * @author Patricia Virgen and Hitarth Asrani   
 ***/
public abstract class Sword 
{
   public int power;
   
    
}
