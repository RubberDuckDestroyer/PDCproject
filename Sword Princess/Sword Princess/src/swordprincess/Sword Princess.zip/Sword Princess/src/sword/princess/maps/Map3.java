/*
 *This class is where the Dragon appears, dark cave.
 */
package sword.princess.maps;

/**
 *
 * @author Patricia Virgen  and  Hitarth Asrani   
 */
public class Map3 {
    
}
