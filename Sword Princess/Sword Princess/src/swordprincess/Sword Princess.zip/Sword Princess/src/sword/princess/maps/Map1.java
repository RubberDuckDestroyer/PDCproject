/*
 *This class follows: This forest takes her to the river where a monster comes out the water and attacks her – here the water sword can be used 
 */
package sword.princess.maps;

/**
 *
 * @author Patricia Virgen and  Hitarth Asrani   
 */
public class Map1 
{
   
}
