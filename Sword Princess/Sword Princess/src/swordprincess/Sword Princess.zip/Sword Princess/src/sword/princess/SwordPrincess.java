
package sword.princess;

/**This class is where the main character instance is created and where the main method runs for the game 
 * 
 * 
 *
 * @author Patricia Virgen and Hitarth Asrani 
 * 
 */
import java.util.Scanner;





/***
 * 
 **/
public class SwordPrincess
{
    
    public String name; 
    private int height; //the charcters height
    private int speed; // speed at which the princess can move 
    
    
    public SwordPrincess()
    {
        
    }
    public SwordPrincess(String name)
    {
        this.name = name; // the name will be provided by the user 
        this. height = height; //height and speed can change depending on how the game is going 
        this.speed = speed; 
    }
  
    /**
     * Method that helps getting the name of the princess 
     * @param String as input from the user 
     * @return String called name
     */
     public String gettingPrincessName()  //need to include try-catch expetions in case a non-string is entered 
     {
         Scanner scan = new Scanner(System.in);
         String name = scan.nextLine();
         return name;
     }
     
    public static void main(String[] args) 
    {
       
        System.out.println("Hello! It's Sword Princress world! Please enter your princess' name");
        SwordPrincess characterName = new SwordPrincess(); // we need to either use the constructor with a string or without 
        
    }
    
}
